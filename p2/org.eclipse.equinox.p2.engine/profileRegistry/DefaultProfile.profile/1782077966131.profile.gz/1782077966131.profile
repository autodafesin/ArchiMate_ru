<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1782077966131'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='D:\Program Files\eclipse-workspace\archigit\archi\com.archimatetool.editor.product\target\products\com.archimatetool.editor.product\win32\win32\x86_64\Archi'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=ru_RU'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='D:\Program Files\eclipse-workspace\archigit\archi\com.archimatetool.editor.product\target\products\com.archimatetool.editor.product\win32\win32\x86_64\Archi'/>
  </properties>
</profile>
